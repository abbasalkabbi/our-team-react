

function Addtodo(){
    return(
        <div class="card-body">
              <div class="d-flex flex-row align-items-center">
                    <input type="text" class="form-control form-control-lg" id="exampleFormControlInput1" placeholder="Add new..."/>
                    
                  
                    
                    <div>
                      <button type="button" class="btn btn-primary">Add</button>
                    </div>
              </div>
        </div>
    )
}
export default Addtodo;